//Osarenren Imasuen, imasu005
//        Salah Mohamed, moha1574
import java.util.Scanner;
public class Game { // Overall Functionality of Chess Game
    public static void main(String[] args) {
        Board theBoard = new Board();
        boolean isBlack = false;
        while (!theBoard.isGameOver()) { // Runs the main game loop
            try {
                if (isBlack) {
                    System.out.println("Black's Turn");
                }
                if (!isBlack) {
                    System.out.println("White's Turn");
                }
                System.out.println(theBoard);
                System.out.println("what is your move? (format:[start row][start col][end row][end col])");
                Scanner myScanner = new Scanner(System.in);
                String input = myScanner.nextLine();
                String[] piece = input.split(" ");
                int piece1 = Integer.parseInt(piece[0]);
                int piece2 = Integer.parseInt(piece[1]);
                int piece3 = Integer.parseInt(piece[2]);
                int piece4 = Integer.parseInt(piece[3]);
                if (theBoard.getPiece(piece1, piece2).getIsBlack() == isBlack &&
                        theBoard.movePiece(piece1, piece2, piece3, piece4)) {;
                    theBoard.getPiece(piece3, piece4).promotePawn(piece3, isBlack);
                    isBlack = !isBlack;
                } else {
                    System.out.println("Invalid Move");
                }
            } catch (ArrayIndexOutOfBoundsException e) {
                System.out.println("Out of Bounds");
            } catch (NullPointerException e) {
                System.out.println("Invalid Move");
            }

            }
            if (theBoard.isGameOver()) { // If King is taken/captured, then player who took the king won.
                if (!isBlack) {
                    System.out.println("Black Won");
                }
                if (isBlack) {
                    System.out.println("White Won");
                }

            }
        }
    }

