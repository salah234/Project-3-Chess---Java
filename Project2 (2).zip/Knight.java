//Osarenren Imasuen, imasu005
//        Salah Mohamed, moha1574
public class Knight {
    private int row; // current row
    private int col; // current col
    private boolean isBlack; // current color of player
    public Knight(int row, int col, boolean isBlack) {
        this.row = row;
        this.col = col;
        this.isBlack = isBlack;
    }
    // Constructor that initializes the variables.
    public boolean isMoveLegal(Board board, int endRow, int endCol) {
        //Checks if the move is either moving horizontally or vertically and it skips over other pieces.
        if (board.verifySourceAndDestination(row,col,endRow,endCol,isBlack)){
            if (Math.abs(endRow-row)==2 && Math.abs(endCol-col)==1){
                return true;
            }
            else if (Math.abs(endRow-row)==1 && Math.abs(endCol-col)==2){
                return true;
            }
        }
        return false;
    }
}


