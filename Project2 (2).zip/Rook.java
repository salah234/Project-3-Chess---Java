//Osarenren Imasuen, imasu005
//        Salah Mohamed, moha1574
public class Rook {
    private int row; // current row
    private int col; // current col
    private boolean isBlack; // current color of player


    public Rook(int row, int col, boolean isBlack) {
        this.row = row;
        this.col = col;
        this.isBlack = isBlack;
    } // Constructor that initializes the variables.
    public boolean isMoveLegal(Board board, int endRow, int endCol) {
        // Checks if the move made is a legal move for the rook piece by seeing if the move goes horizontally or vertically.
        if (!board.verifySourceAndDestination(this.row, this.col, endRow, endCol, isBlack)) {
            return false;
        }
        if (board.verifySourceAndDestination(row,col,endRow,endCol,isBlack)
                && board.verifyVertical(row,col,endRow,endCol) || board.verifyHorizontal(row,col,endRow,endCol)){
            return true;
        }
        return false;
    }
}

