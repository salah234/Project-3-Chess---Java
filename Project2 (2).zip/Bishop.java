//Osarenren Imasuen, imasu005
//        Salah Mohamed, moha1574
public class Bishop {
    private int row; // current row
    private int col; // current col
    private boolean isBlack; // current color of player


    public Bishop(int row, int col, boolean isBlack) {
        this.row = row;
        this.col = col;
        this.isBlack = isBlack;
    } // Constructor that initializes the variables.
    public boolean isMoveLegal(Board board, int endRow, int endCol) {
        // Checks if the move made is going diagonally.
        if (board.verifySourceAndDestination(this.row, this.col, endRow, endCol, isBlack) &&
                (board.verifyDiagonal(row, col, endRow, endCol))) {
            return true;
        }
        return false;
    }
}

