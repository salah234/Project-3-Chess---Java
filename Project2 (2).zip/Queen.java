// Osarenren Imasuen, imasu005
//        Salah Mohamed, moha1574
public class Queen {
    private int row; // current row
    private int col; // current col
    private boolean isBlack; // current color

    public Queen(int row, int col, boolean isBlack) {
        this.row = row;
        this.col = col;
        this.isBlack = isBlack;
    } // Constructor containing the initialized private variables

    public boolean isMoveLegal(Board board, int endRow, int endCol) {
        // checks if the move is legal horizontally, vertically, and diagonally while checking if it is in
        // bounds of the board array.
        if (!board.verifySourceAndDestination(this.row, this.col, endRow, endCol, isBlack)) {
            return false;
        }
        if (board.verifySourceAndDestination(this.row, this.col, endRow, endCol, isBlack) &&
                (board.verifyHorizontal(this.row, this.col, endRow, endCol) || board.verifyDiagonal(this.row, this.col, endRow, endCol)
                || board.verifyVertical(this.row, this.col, endRow, endCol))) {
            return true;
        }
        return false;
    }
}

