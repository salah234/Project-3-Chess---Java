Names : Osarenren Imasuen, imasu005
      Salah Mohamed, moha1574
Contributions: Osarenren Imasuen: Rook class, knight class, Bishop class, verify diagonal, verify source and destination, game class.
              Salah Mohamed: King class, Queen class, Pawn Promotion, verify vertical, verify horizontal, verify adjacent.
How to Compile and run your program:  From Command Prompt :  Go into terminal and access 16122 directory from Users
                                                            Access IdeaProjects directory
                                                            Access Project 2 CSCI 1933
                                                            Access Source Code Folder (src) from Project 2 CSCI 1933
                                                            File Location: C:\Users\16122\IdeaProjects\Project 2 CSCI 1933
Any Assumptions:  There is only one way that the game can end and that is if one of the kings is captured.
                  Another assumption would be that the user would put spaces between numbers each time they make a move.
                  Another assumption would be that the Fen.load method in Game.java works with the provided Fen Class.
Any known bugs or defects in the program: When you play the game in dark mode the pieces that are white appear dark and the pieces that are black appear white.
                                          Minor bug: When captured king, it ends but doesn't go to location of king.
Any outside sources: No outside sources.
Additional features that you implemented (if applicable): Not applicable
Statement: “I certify that the information contained in this README
file is complete and accurate. I have both read and followed the course policies
in the ‘Academic Integrity - Course Policy’ section of the course syllabus.”
Osarenren Imasuen
Salah Mohamed

